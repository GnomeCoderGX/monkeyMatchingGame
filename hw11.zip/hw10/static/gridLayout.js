var imageArray = []
var choice1 = ""
var choice2 = ""
var matches = 0
var misses = 0

function init(){
    var images = ["static/monkey1.jpg", "static/monkey1.jpg", "static/monkey2.jpg", "static/monkey2.jpg",
                  "static/monkey3.jpg", "static/monkey3.jpg", "static/monkey4.jpg", "static/monkey4.jpg",
                  "static/monkey5.jpg", "static/monkey5.jpg", "static/monkey6.jpg", "static/monkey6.jpg",]
    var image = document.getElementsByClassName("image")
    for(var i=0; i<12; i++){
        var l = image[i]
        var j = Math.floor(Math.random() * (images.length))
        imageArray.push(images[j])
        images.splice(j, 1)
    }
}

function clickItem(img){
    if(!img.src.includes("static/mysterymonkey.jpg") || choice2 != ""){
        return;
    }
    img.src=imageArray[img.id]
    if(choice1 == ""){
        choice1 = img
    }else{
        choice2 = img
        if(choice1.src == choice2.src){
            matches++
            var counter = document.getElementById("matches")
            counter.innerHTML = "MONKEY MATCHES: " + matches
            console.log("hiiiiiiiiii")
            choice1 = ""
            choice2 = ""
        }else{
            misses++
            var counter = document.getElementById("misses")
            counter.innerHTML = "MONKEY MISSES: " + misses
            setTimeout(revert, 1000, choice2, choice1)
        }
    }
    if(matches == 6){
        if(misses > 5){
            setTimeout(alert("you lose"), 1000)
        }else{
            setTimeout(alert("you win"), 1000)
        }
    }
}

function revert(img, img2){
    img.src="/static/mysterymonkey.jpg"
    img2.src="/static/mysterymonkey.jpg"
    choice1 = ""
    choice2 = ""
}


window.onload = init;
